from .dotscope_core import *

__doc__ = dotscope_core.__doc__
if hasattr(dotscope_core, "__all__"):
    __all__ = dotscope_core.__all__