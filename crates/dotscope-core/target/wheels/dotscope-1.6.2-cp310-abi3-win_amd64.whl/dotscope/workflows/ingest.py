"""Ingest: reverse-engineer .scope files from an existing codebase.

Orchestrates graph analysis, git history mining, and doc absorption
to produce complete .scope files for every detected module boundary.

This is how dotscope enters any codebase — not by asking humans to write
.scope files, but by inferring them from signals already in the code.
"""


import os
import sys
from pathlib import Path
from typing import List, Optional, Set, Tuple

from ..workflows.absorber import AbsorptionResult, absorb_docs
from ..engine.context import parse_context
from ..models.core import DependencyGraph, ModuleBoundary
from ..models.history import HistoryAnalysis
from ..passes.graph_builder import build_graph, transitive_dependents
from ..passes.history_miner import analyze_history
from ..models.core import ScopeConfig, ScopesIndex, ScopeEntry
from ..models.passes import IngestPlan, PlannedScope  # noqa: F401
from ..models.state import BacktestReport
from ..engine.parser import serialize_scope
from ..paths import (
    normalize_directory_include,
    normalize_relative_path,
    normalize_scope_ref,
)
from ..engine.tokens import estimate_scope_tokens


def _safe_print(text, **kwargs):
    """Print with ASCII fallback for Windows cp1252 terminals."""
    try:
        print(text, **kwargs)
    except UnicodeEncodeError:
        print(text.encode("ascii", errors="replace").decode("ascii"), **kwargs)


def _log_ingest_error(root: str, message: str) -> None:
    """Append error to .dotscope/error.log for debugging."""
    try:
        log_dir = os.path.join(root, ".dotscope")
        os.makedirs(log_dir, exist_ok=True)
        import time
        with open(os.path.join(log_dir, "error.log"), "a", encoding="utf-8") as f:
            f.write(f"[{time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}] {message}\n")
    except Exception:
        pass  # Logging failure should never block ingest


def ingest(
    root: str,
    mine_history: bool = True,
    absorb: bool = True,
    synthesize: bool = True,
    max_commits: int = 500,
    dry_run: bool = False,
    quiet: bool = False,
    voice_override: Optional[str] = None,
    respect_existing_scopes: bool = True,
) -> IngestPlan:
    """Ingest a codebase and produce .scope files.

    Pipeline:
    1. Build dependency graph → detect module boundaries
    2. Mine git history → change coupling, hotspots, implicit contracts
    3. Absorb existing docs → README, docstrings, signal comments
    4. Synthesize .scope files → combine all signals into scope configs
    5. Optionally write files to disk

    Args:
        root: Repository root
        mine_history: Whether to analyze git history
        absorb: Whether to absorb existing documentation
        synthesize: Whether to use LLM for context synthesis (falls back to template)
        max_commits: Max git commits to analyze
        dry_run: If True, plan but don't write files
    """
    root = os.path.abspath(root)
    plan = IngestPlan(root=root)

    from ..ux.progress import ProgressEmitter
    progress = ProgressEmitter(quiet=quiet)

    # --- SUPREMUM FFI BIFURCATION ---
    try:
        import threading
        from dotscope import dotscope_core
        progress.start("invoking bare-metal rust physics engine")
        print(f"[{threading.get_native_id()}] Calling Python Pyo3 Bridge -> dotscope_core.ingest_repository")
        topology_raw = dotscope_core.ingest_repository(root, max_commits, mine_history)
        
        # Bifurcate the payload
        manifest_path = os.path.join(root, ".dotscope", "structural_manifest.json")
        bin_path = os.path.join(root, ".dotscope", "topology.bin")
        os.makedirs(os.path.dirname(manifest_path), exist_ok=True)
        
        # Isolate semantic strings inside JSON boundary
        import json
        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump({
                "nodes": topology_raw.get("node_names", []),
                "commits_analyzed": topology_raw.get("commits_analyzed", 0)
            }, f)
        
        # Flush the zero-copy array entirely bypassing serialization
        with open(bin_path, "wb") as f:
            f.write(topology_raw.get("edge_sources", b""))
            f.write(topology_raw.get("edge_targets", b""))
            f.write(topology_raw.get("edge_weights", b""))
        progress.finish("Zero-copy WebGPU pipeline synchronized")
    except ImportError:
        pass # Fallback to python standard pipeline if deployed in non-native environments
    # --------------------------------

    # Step 0: Dependency graph (Moved up for Topological Physics)
    progress.start("building dependency graph")
    graph = build_graph(root)
    plan.graph = graph
    plan.total_repo_files = len(graph.files)
    plan.total_repo_tokens = sum(
        estimate_scope_tokens([os.path.join(root, p)])
        for p in graph.files
    )
    from ..passes.graph_builder import format_graph_summary
    plan.graph_summary = format_graph_summary(graph)
    edge_count = sum(len(n.imports) for n in graph.files.values())
    progress.finish(f"{len(graph.files)} files, {edge_count} edges, {len(graph.modules)} modules")

    # Step 1: Federated Templates & Topological Directives (Removed to Pro Backend)

    # Step 2: Git history
    history = HistoryAnalysis()
    if mine_history:
        progress.start(f"mining git history ({max_commits} commits)")
        history = analyze_history(root, max_commits=max_commits)
        from ..passes.history_miner import format_history_summary
        plan.history_summary = format_history_summary(history)
        contracts = len(history.implicit_contracts)
        progress.finish(f"{history.commits_analyzed} commits, {contracts} contracts")
    else:
        progress.skip("mining git history", "disabled")
    plan.history = history

    # Step 3: Doc absorption (with AST data if available)
    docs = AbsorptionResult()
    if absorb:
        progress.start("absorbing documentation")
        docs = absorb_docs(root, apis=graph.apis if graph.apis else None)
        progress.finish(f"{len(docs.fragments)} fragments")
    else:
        progress.skip("absorbing documentation", "disabled")

    # Step 3b: Discover conventions from structural patterns
    if graph.apis:
        progress.start("discovering conventions")
        from ..passes.convention_discovery import discover_conventions
        from ..passes.convention_parser import parse_conventions
        from ..passes.convention_compliance import compute_compliance
        discovered = discover_conventions(graph.apis, graph, history)
        if discovered:
            nodes = parse_conventions(graph.apis, discovered)
            for conv in discovered:
                conv.compliance = compute_compliance(conv, nodes, graph.apis)
            viable = [c for c in discovered if c.compliance >= 0.5]
            plan.discovered_conventions = viable
            if viable and not dry_run:
                from ..workflows.intent import save_conventions
                save_conventions(root, viable)
            progress.finish(f"{len(viable) if discovered else 0} patterns")
        else:
            progress.finish("0 patterns")

    # Step 3c: Voice discovery
    if graph.apis:
        progress.start("discovering voice")
        from ..passes.voice_discovery import detect_codebase_maturity, discover_voice
        from ..passes.voice_defaults import prescriptive_defaults
        maturity = detect_codebase_maturity(graph.apis, history, voice_override)
        if maturity == "new":
            discovered_voice = prescriptive_defaults()
            # Inject prescriptive spatial conventions for greenfield repos
            if not plan.discovered_conventions:
                from ..passes.voice_defaults import prescriptive_spatial_conventions
                spatial_convs = prescriptive_spatial_conventions()
                plan.discovered_conventions = spatial_convs
                if not dry_run:
                    from ..workflows.intent import save_conventions
                    save_conventions(root, spatial_convs)
        else:
            discovered_voice = discover_voice(graph.apis, root)
        if not dry_run:
            from ..workflows.intent import save_voice_config
            save_voice_config(root, discovered_voice)
        progress.finish(f"{maturity} mode")

    # Step 3d: Build search index (vector + BM25)
    if graph.apis and not dry_run:
        progress.start("building search index")
        try:
            from ..search.chunker import chunk_file, chunk_artifact, reset_chunk_counter
            from ..search.retriever import build_vector_index
            from ..search.models import RetrievalChunk

            reset_chunk_counter()
            all_chunks = []

            # Chunk source files
            for rel_path, analysis in graph.apis.items():
                try:
                    full_path = os.path.join(root, rel_path)
                    if os.path.isfile(full_path):
                        source = open(full_path, "r", encoding="utf-8", errors="replace").read()
                        chunks = chunk_file(rel_path, analysis, source)
                        all_chunks.extend(chunks)
                except Exception:
                    continue

            # Chunk context artifacts if .dotscope_artifacts.yaml exists
            artifacts_path = os.path.join(root, ".dotscope_artifacts.yaml")
            if os.path.isfile(artifacts_path):
                try:
                    from ..engine.parser import _parse_yaml
                    artifacts_data = _parse_yaml(
                        open(artifacts_path, "r", encoding="utf-8").read()
                    )
                    for artifact in artifacts_data.get("artifacts", []):
                        art_path = artifact.get("path", "")
                        art_name = artifact.get("name", art_path)
                        full_art = os.path.join(root, art_path)
                        if os.path.isfile(full_art):
                            content = open(full_art, "r", encoding="utf-8", errors="replace").read()
                            art_chunks = chunk_artifact(art_name, art_path, content)
                            all_chunks.extend(art_chunks)
                        elif os.path.isdir(full_art):
                            for dirpath, _, filenames in os.walk(full_art):
                                for fname in filenames:
                                    fpath = os.path.join(dirpath, fname)
                                    rel = os.path.relpath(fpath, root)
                                    content = open(fpath, "r", encoding="utf-8", errors="replace").read()
                                    art_chunks = chunk_artifact(art_name, rel, content)
                                    all_chunks.extend(art_chunks)
                except Exception:
                    pass

            # Cap chunk count to prevent OOM on large repos
            max_chunks = 50_000
            if len(all_chunks) > max_chunks:
                # Prefer source files over tests/configs
                def _chunk_priority(c):
                    p = c.file_path.lower()
                    if "/test" in p or p.startswith("test"):
                        return 2
                    if any(p.endswith(e) for e in (".json", ".yaml", ".yml", ".toml")):
                        return 1
                    return 0
                all_chunks.sort(key=lambda c: (_chunk_priority(c), c.file_path))
                _safe_print(
                    f"dotscope: {len(all_chunks)} chunks exceeds limit,"
                    f" keeping top {max_chunks}",
                    file=sys.stderr,
                )
                all_chunks = all_chunks[:max_chunks]

            if all_chunks:
                index = build_vector_index(root, all_chunks)
                progress.finish(f"{index.chunk_count} chunks, {index.model_name}")
            else:
                progress.finish("0 chunks")
        except Exception as e:
            import traceback
            _safe_print(
                f"dotscope: search index failed: {e}\n"
                f"  Scopes still work. Search will be unavailable.\n"
                f"  Try: dotscope ingest . --max-chunks 25000",
                file=sys.stderr,
            )
            # Log full traceback for debugging
            _log_ingest_error(root, traceback.format_exc())
            progress.finish("failed")

    # Step 4: Synthesize scope files
    progress.start("generating scopes")
    for module in graph.modules:
        planned = synthesize_scope(
            module,
            graph,
            history,
            docs,
            root,
            synthesize,
            respect_existing_scopes=respect_existing_scopes,
        )
        if planned:
            plan.scopes.append(planned)

    # Step 4b: Detect virtual (cross-cutting) scopes
    from ..passes.virtual import detect_virtual_scopes
    virtual_scopes = detect_virtual_scopes(graph)
    plan.virtual_scopes = virtual_scopes
    for vs in virtual_scopes:
        plan.scopes.append(PlannedScope(
            directory=_planned_scope_directory(root, vs),
            config=vs,
            confidence=0.7,
            signals=["graph: cross-cutting hub detection"],
        ))
    real_count = len([s for s in plan.scopes if not s.directory.startswith("virtual/")])
    virtual_count = len(virtual_scopes)
    progress.finish(f"{real_count} scopes, {virtual_count} virtual")

    # Step 5: Backtest against git history and auto-correct
    if mine_history and plan.scopes:
        progress.start(f"backtesting ({min(max_commits, 50)} commits)")
        from ..passes.backtest import backtest_scopes, auto_correct_scope, format_backtest_report

        configs = [ps.config for ps in plan.scopes]
        report = backtest_scopes(root, configs, n_commits=min(max_commits, 50))

        # Auto-correct: up to 2 rounds
        for correction_round in range(2):
            any_corrected = False
            for i, result in enumerate(report.results):
                if result.recall < 1.0 and result.missing_includes:
                    updated, changed = auto_correct_scope(
                        plan.scopes[i].config, result, root
                    )
                    if changed:
                        plan.scopes[i].config = updated
                        plan.scopes[i].signals.append(
                            f"backtest: auto-corrected {len(result.missing_includes)} missing include(s)"
                        )
                        any_corrected = True

            if not any_corrected:
                break

            # Re-run backtest after corrections
            configs = [ps.config for ps in plan.scopes]
            report = backtest_scopes(root, configs, n_commits=min(max_commits, 50))

        plan.backtest_summary = format_backtest_report(report)
        plan.backtest_report = report
        progress.finish(f"{report.overall_recall:.0%} recall")
    elif not mine_history:
        progress.skip("backtesting", "no history")

    # Build .scopes index
    plan.index = _build_index(plan.scopes, plan.total_repo_tokens)

    # Step 6: Write to disk
    if not dry_run:
        _write_scopes(plan)
        # Cache structured data for MCP server
        from ..storage.cache import cache_ingest_data
        cache_ingest_data(root, history=plan.history, graph=plan.graph)
        # Cache invariants for enforcement
        _cache_invariants(root, plan.history)
        # Synthesize actionable Mathematical Z3 boundaries based on graph state 
        try:
            from ..passes.z3_transpiler import synthesize_proofs
            synthesize_proofs(root, plan.graph, plan.history, target_dir=".dotscope/proofs")
        except Exception as e:
            _log_ingest_error(root, f"Z3 Transpiler Proof Compilation Failed: {e}")
        # Reset incremental state + remove needs_full_ingest marker
        try:
            from ..storage.incremental_state import reset_incremental_state
            reset_incremental_state(
                root,
                scope_paths=_refreshed_scope_paths(root, graph.modules, virtual_scopes),
            )
            marker = os.path.join(root, ".dotscope", "needs_full_ingest")
            if os.path.exists(marker):
                os.remove(marker)
        except Exception:
            pass
        try:
            from dotscope.engine.runtime_overlay import sync_runtime_overlay
            sync_runtime_overlay(root)
        except Exception:
            pass

    return plan


def synthesize_scope(
    module: ModuleBoundary,
    graph: DependencyGraph,
    history: HistoryAnalysis,
    docs: AbsorptionResult,
    root: str,
    use_llm: bool,
    respect_existing_scopes: bool = True,
) -> Optional[PlannedScope]:
    """Synthesize a single .scope file from all available signals."""
    directory = module.directory
    scope_path = os.path.join(root, directory, ".scope")

    # Skip if .scope already exists
    if respect_existing_scopes and os.path.exists(scope_path):
        return None

    signals = []

    # --- Description ---
    file_count = len(module.files)
    # Detect primary language
    langs = {}
    for f in module.files:
        ext = os.path.splitext(f)[1]
        langs[ext] = langs.get(ext, 0) + 1
    primary_ext = max(langs, key=langs.get) if langs else ""
    lang_names = {
        ".py": "Python", ".js": "JavaScript", ".ts": "TypeScript",
        ".go": "Go", ".rs": "Rust", ".rb": "Ruby", ".java": "Java",
    }
    lang = lang_names.get(primary_ext, "")

    description = f"{directory} module"
    if lang:
        description = f"{directory} -- {lang} module ({file_count} files)"

    signals.append(f"graph: {file_count} files, cohesion {module.cohesion:.0%}")
    directory_prefix = normalize_directory_include(directory)

    # --- Includes ---
    includes = [directory_prefix]

    # Add cross-module dependencies detected from imports
    for dep in module.external_deps:
        dep_dir = os.path.join(root, dep)
        if os.path.isdir(dep_dir):
            # Find specific files imported, not the whole directory
            imported_files = _find_cross_module_imports(module, dep, graph)
            for imp_file in imported_files:
                if imp_file not in includes:
                    includes.append(imp_file)

    # Add change-coupled files from other modules
    for coupling in history.change_couplings:
        file_a = normalize_relative_path(coupling.file_a)
        file_b = normalize_relative_path(coupling.file_b)
        for current, other in ((file_a, file_b), (file_b, file_a)):
            if current.startswith(directory_prefix):
                if not other.startswith(directory_prefix) and coupling.coupling_strength >= 0.7:
                    if other not in includes:
                        includes.append(other)
                        signals.append(f"history: {other} coupled at {coupling.coupling_strength:.0%}")

    # --- Excludes ---
    excludes = _default_excludes(directory, module.files)

    # --- Context (priority: contracts → stability → docs → deps → recent → transitive) ---
    context_parts = []

    # 1. Implicit contracts FIRST — the thing nobody documented
    relevant_contracts = [
        ic for ic in history.implicit_contracts
        if normalize_relative_path(ic.trigger_file).startswith(directory_prefix)
        or normalize_relative_path(ic.coupled_file).startswith(directory_prefix)
    ]
    if relevant_contracts:
        context_parts.append("## Implicit Contracts (from git history)")
        for ic in relevant_contracts[:5]:
            context_parts.append(f"- {ic.description}")
        signals.append(f"history: {len(relevant_contracts)} implicit contracts")

    # 2. Stability profiles — which files are fragile
    stability_lines = []
    for f in module.files:
        fh = history.file_histories.get(f)
        if fh and fh.stability and fh.commit_count >= 3:
            lines_info = f", {fh.total_lines_changed} lines" if fh.total_lines_changed else ""
            stability_lines.append(
                f"- {os.path.basename(f)}: {fh.stability} ({fh.commit_count} commits{lines_info})"
            )
    if stability_lines:
        context_parts.append("## Stability")
        context_parts.extend(stability_lines[:10])

    # 3. Absorbed docs — READMEs, docstrings, signal comments
    doc_context = docs.synthesize_context(directory, max_chars=1500)
    if doc_context:
        context_parts.append(doc_context)
        signals.append(f"docs: absorbed {len(docs.for_module(directory))} fragments")

    # 4. Dependencies + structural
    if module.external_deps:
        context_parts.append("## Dependencies")
        context_parts.append(f"This module imports from: {', '.join(module.external_deps)}")
    if module.depended_on_by:
        context_parts.append(f"This module is used by: {', '.join(module.depended_on_by)}")
        context_parts.append("Changes here may affect downstream consumers.")

    # 5. Recent changes
    recent = history.recent_summaries.get(directory, [])
    if recent:
        context_parts.append("## Recent Changes")
        for msg in recent[:5]:
            context_parts.append(f"- {msg}")

    # 6. Transitive dependency chain (if deeper than 1 hop)
    from ..passes.graph_builder import transitive_deps as _transitive_deps
    deep_deps: Set[str] = set()
    for f in module.files:
        for dep in _transitive_deps(graph, f):
            dep_parts = dep.split("/")
            if len(dep_parts) > 1 and dep_parts[0] != directory:
                deep_deps.add(dep)
    if deep_deps:
        direct: Set[str] = set()
        for dep in module.external_deps:
            direct.update(d for d in deep_deps if d.startswith(dep + "/"))
        transitive_only = deep_deps - direct
        if transitive_only:
            context_parts.append("## Transitive Dependencies")
            for dep in sorted(transitive_only)[:5]:
                context_parts.append(f"- {dep} (indirect)")

    # 7. NEVER TODO. If empty, synthesize from graph structure.
    if not context_parts:
        context_parts.append(
            f"{directory} module -- {file_count} files, "
            f"cohesion {module.cohesion:.0%}, "
            f"{len(module.external_deps)} external dependencies."
        )

    context_str = "\n".join(context_parts)
    context = parse_context(context_str)

    # --- Related ---
    related = []
    for dep in module.external_deps:
        scope_candidate = normalize_scope_ref(f"{dep}/.scope")
        related.append(scope_candidate)
    for dep_by in module.depended_on_by:
        scope_candidate = normalize_scope_ref(f"{dep_by}/.scope")
        if scope_candidate not in related:
            related.append(scope_candidate)

    # --- Tags ---
    tags = [directory.lower()]
    if module.external_deps:
        tags.extend(d.lower() for d in module.external_deps[:3])

    # --- Token estimate ---
    full_paths = [os.path.join(root, f) for f in module.files]
    token_est = estimate_scope_tokens(full_paths)

    # --- Confidence ---
    confidence = module.cohesion
    if doc_context:
        confidence = min(confidence + 0.1, 1.0)
    if relevant_contracts:
        confidence = min(confidence + 0.1, 1.0)

    config = ScopeConfig(
        path=scope_path,
        description=description,
        includes=includes,
        excludes=excludes,
        context=context,
        related=related,
        owners=[],
        tags=tags,
        tokens_estimate=token_est,
    )

    return PlannedScope(
        directory=directory,
        config=config,
        confidence=confidence,
        signals=signals,
    )


def _planned_scope_directory(root: str, config: ScopeConfig) -> str:
    """Return the canonical directory segment for a planned scope."""
    return normalize_relative_path(os.path.relpath(os.path.dirname(config.path), root))


def _scope_index_path(directory: str) -> str:
    """Return the canonical .scopes entry path for a scope directory."""
    return normalize_scope_ref(f"{directory}/.scope")


def _refreshed_scope_paths(
    root: str,
    modules: List[ModuleBoundary],
    virtual_scopes: List[ScopeConfig],
) -> List[str]:
    """Return every discovered scope path that should be marked freshly ingested."""
    scope_paths = [os.path.join(root, module.directory, ".scope") for module in modules]
    scope_paths.extend(scope.path for scope in virtual_scopes)
    return scope_paths


def _find_cross_module_imports(
    module: ModuleBoundary, dep_module: str, graph: DependencyGraph
) -> List[str]:
    """Find specific files in dep_module that are imported by files in module."""
    imported = set()
    for f in module.files:
        node = graph.files.get(f)
        if not node:
            continue
        for imp in node.imports:
            if imp.startswith(normalize_directory_include(dep_module)):
                imported.add(imp)
    return sorted(imported)


def _default_excludes(directory: str, files: List[str]) -> List[str]:
    """Generate sensible excludes for a module."""
    excludes = []

    # Common patterns
    excludes.append(f"{directory}/__pycache__/")
    excludes.append("*.pyc")

    # Detect test/fixture/migration directories
    subdirs = set()
    for f in files:
        parts = normalize_relative_path(f).split("/")
        if len(parts) > 2:  # directory/subdir/file
            subdirs.add(parts[1])

    for subdir in subdirs:
        subdir_lower = subdir.lower()
        if subdir_lower in ("fixtures", "fixture", "testdata", "test_data", "mocks"):
            excludes.append(f"{directory}/{subdir}/")
        if subdir_lower in ("migrations", "migrate"):
            excludes.append(f"{directory}/{subdir}/")

    return excludes


def _build_index(
    scopes: List[PlannedScope], total_repo_tokens: int = 0,
) -> ScopesIndex:
    """Build a .scopes index from planned scopes."""
    entries = {}
    for ps in scopes:
        name = ps.directory
        keywords = list(ps.config.tags)
        # Add words from description
        for word in ps.config.description.split():
            word = word.lower().strip("—()-,.")
            if len(word) > 2 and word not in keywords:
                keywords.append(word)

        entries[name] = ScopeEntry(
            name=name,
            path=_scope_index_path(ps.directory),
            keywords=keywords[:15],  # Cap at 15
            description=ps.config.description,
        )

    return ScopesIndex(
        version=1,
        scopes=entries,
        defaults={"max_tokens": 8000, "include_related": False},
        total_repo_tokens=total_repo_tokens,
    )


def append_to_index(root: str, planned: PlannedScope) -> None:
    """Append a single scope entry to the .scopes index on disk."""
    from ..engine.discovery import load_index
    index = load_index(root)
    if index is None:
        index = ScopesIndex(version=1, scopes={}, defaults={"max_tokens": 8000, "include_related": False})

    name = planned.directory
    keywords = list(planned.config.tags)
    for word in planned.config.description.split():
        word = word.lower().strip("—()-,.")
        if len(word) > 2 and word not in keywords:
            keywords.append(word)

    index.scopes[name] = ScopeEntry(
        name=name,
        path=_scope_index_path(planned.directory),
        keywords=keywords[:15],
        description=planned.config.description,
    )

    index_path = os.path.join(root, ".scopes")
    content = _serialize_index(index)
    with open(index_path, "w", encoding="utf-8") as f:
        f.write(content)


def _write_scopes(plan: IngestPlan) -> None:
    """Write all planned .scope files and the .scopes index to disk."""
    written = 0

    for ps in plan.scopes:
        scope_path = ps.config.path
        # Don't overwrite existing
        if os.path.exists(scope_path):
            continue

        os.makedirs(os.path.dirname(scope_path), exist_ok=True)
        content = serialize_scope(ps.config)
        with open(scope_path, "w", encoding="utf-8") as f:
            f.write(content)
        written += 1

    # Write .scopes index (only if it doesn't exist)
    index_path = os.path.join(plan.root, ".scopes")
    if plan.index and not os.path.exists(index_path):
        content = _serialize_index(plan.index)
        with open(index_path, "w", encoding="utf-8") as f:
            f.write(content)
        written += 1

    import json
    real_scopes = [s for s in plan.scopes if not s.directory.startswith("virtual/")]
    avg_tokens = 0
    if real_scopes:
        avg_tokens = sum(s.config.tokens_estimate or 0 for s in real_scopes) / max(len(real_scopes), 1)
        
    manifest_data = {
        "telemetry_paths": {
            "graph": ".dotscope/cache/graph.json",
            "history": ".dotscope/cache/history.json",
            "npmi_index": ".dotscope/cache/npmi_index.json",
            "scopes_index": ".scopes"
        },
        "bounds": {
            "total_repo_tokens": plan.total_repo_tokens,
            "average_scope_tokens": int(avg_tokens),
            "total_scopes": len(plan.scopes)
        }
    }
    try:
        manifest_path = os.path.join(plan.root, ".dotscope", "manifest.json")
        os.makedirs(os.path.dirname(manifest_path), exist_ok=True)
        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump(manifest_data, f, indent=2)
    except Exception as e:
        _log_ingest_error(plan.root, f"Failed to write manifest.json: {e}")

    pass  # Progress is handled by the caller


def _serialize_index(index: ScopesIndex) -> str:
    """Serialize a ScopesIndex to .scopes YAML format."""
    lines = [f"version: {index.version}"]
    if index.total_repo_tokens:
        lines.append(f"total_repo_tokens: {index.total_repo_tokens}")
    lines.extend(["", "scopes:"])

    for name, entry in sorted(index.scopes.items()):
        lines.append(f"  {name}:")
        lines.append(f"    path: {entry.path}")
        kw_str = ", ".join(entry.keywords)
        lines.append(f"    keywords: [{kw_str}]")

    lines.append("")
    lines.append("defaults:")
    for k, v in index.defaults.items():
        if isinstance(v, bool):
            lines.append(f"  {k}: {'true' if v else 'false'}")
        else:
            lines.append(f"  {k}: {v}")

    return "\n".join(lines) + "\n"


def _use_unicode() -> bool:
    """Check if stdout can handle Unicode (emoji, box-drawing)."""
    import io
    enc = getattr(sys.stdout, "encoding", None) or ""
    if isinstance(sys.stdout, io.TextIOWrapper):
        enc = sys.stdout.encoding or ""
    return enc.lower().replace("-", "") in ("utf8", "utf16", "utf32", "utf8sig")


# Glyph sets: Unicode vs ASCII-safe fallbacks
_GLYPHS_UNICODE = {
    "discoveries": "\u26a1 Discoveries",
    "validation": "\U0001f4ca Validation",
    "created": "\U0001f4c1 Created",
    "bar_full": "\u2588",
    "bar_empty": "\u2591",
    "arrow": "\u2192",
    "dash": "\u2014",
    "attention": "\u2190 needs attention",
}
_GLYPHS_ASCII = {
    "discoveries": ">> Discoveries",
    "validation": ">> Validation",
    "created": ">> Created",
    "bar_full": "#",
    "bar_empty": ".",
    "arrow": "->",
    "dash": "--",
    "attention": "<- needs attention",
}


def _glyphs() -> dict:
    """Return the appropriate glyph set for the current terminal."""
    return _GLYPHS_UNICODE if _use_unicode() else _GLYPHS_ASCII


def format_ingest_report(plan: IngestPlan) -> str:
    """Format the discovery-first ingest report."""
    g = _glyphs()
    lines = []

    # --- Header ---
    real_scopes = [s for s in plan.scopes if not s.directory.startswith("virtual/")]
    module_count = len(real_scopes)
    lines.append(
        f"dotscope scanned {plan.total_repo_files} files "
        f"across {module_count} modules."
    )
    lines.append("")

    # --- Section 1: Discoveries ---
    discoveries = _extract_discoveries(plan, g)
    if discoveries:
        lines.append(g["discoveries"])
        lines.append("")
        lines.extend(discoveries)

    # --- Section 2: Validation ---
    validation = _extract_validation(plan, g)
    if validation:
        lines.append(g["validation"])
        lines.append("")
        lines.extend(validation)

    # --- Section 3: Files created ---
    lines.append(f"{g['created']} {len(real_scopes)} .scope files + .scopes index")
    lines.append("")
    lines.append("  Try it:  dotscope resolve <module>")
    lines.append("  See it:  dotscope resolve <module> --json --budget 4000")
    lines.append("  Trust it: dotscope backtest --commits 500")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Discovery extraction helpers
# ---------------------------------------------------------------------------


def _is_cross_module(file_a: str, file_b: str) -> bool:
    """True if two files are in different top-level directories."""
    file_a = normalize_relative_path(file_a)
    file_b = normalize_relative_path(file_b)
    dir_a = file_a.split("/")[0] if "/" in file_a else ""
    dir_b = file_b.split("/")[0] if "/" in file_b else ""
    return dir_a != dir_b and bool(dir_a) and bool(dir_b)


def _find_hub_discoveries(
    graph: DependencyGraph,
) -> List[Tuple[str, int, int, int]]:
    """Find files with high import fan-in across multiple modules.

    Returns: [(path, importer_count, directory_count, blast_radius)]
    """
    results = []
    for path, node in graph.files.items():
        if not node.imported_by:
            continue
        importer_dirs: Set[str] = set()
        for imp_by in node.imported_by:
            parts = Path(imp_by).parts
            if len(parts) > 1:
                importer_dirs.add(parts[0])

        if len(node.imported_by) >= 3 and len(importer_dirs) >= 2:
            blast = transitive_dependents(graph, path)
            results.append((
                path,
                len(node.imported_by),
                len(importer_dirs),
                len(blast) + 1,  # +1 for the file itself
            ))

    results.sort(key=lambda x: -x[1])
    return results


# Directories an engineer expects to be stable
_EXPECTED_STABLE = {
    "config", "configs", "settings", "constants",
    "migrations", "fixtures", "static",
}


def _find_volatility_surprises(
    history: HistoryAnalysis,
) -> List[Tuple[str, "FileHistory"]]:
    """Files classified volatile that live in directories expected to be stable."""
    from ..models.history import FileHistory  # noqa: F811 — type hint only

    surprises: List[Tuple[str, FileHistory]] = []
    for path, fh in history.file_histories.items():
        if fh.stability != "volatile":
            continue
        parts = normalize_relative_path(path).split("/")
        if len(parts) > 1 and parts[0].lower() in _EXPECTED_STABLE:
            surprises.append((normalize_relative_path(path), fh))

    # Also include the repo's most-changed file if high churn
    if history.hotspots:
        top_path, _top_churn = history.hotspots[0]
        top_fh = history.file_histories.get(top_path)
        if top_fh and top_fh.commit_count >= 10:
            top_path = normalize_relative_path(top_path)
            if not any(p == top_path for p, _ in surprises):
                surprises.insert(0, (top_path, top_fh))

    surprises.sort(key=lambda x: -x[1].total_lines_changed)
    return surprises


def _extract_discoveries(plan: IngestPlan, g: Optional[dict] = None) -> List[str]:
    """Extract surprising findings from history, graph, and docs."""
    if g is None:
        g = _glyphs()
    lines: List[str] = []
    history = plan.history
    graph = plan.graph

    # --- Hidden dependencies (cross-module implicit contracts) ---
    if history and history.implicit_contracts:
        cross_module = [
            ic for ic in history.implicit_contracts
            if _is_cross_module(ic.trigger_file, ic.coupled_file)
            and ic.confidence >= 0.65
        ]
        if cross_module:
            lines.append(
                f"  Hidden dependencies "
                f"(from {history.commits_analyzed} commits of git history):"
            )
            for ic in cross_module[:5]:
                trigger = os.path.basename(ic.trigger_file)
                coupled = os.path.basename(ic.coupled_file)
                if trigger == coupled:
                    trigger = ic.trigger_file
                    coupled = ic.coupled_file
                lines.append(
                    f"    {trigger} {g['arrow']} {coupled}"
                    f"    {ic.confidence:.0%} co-change, undocumented"
                )
            lines.append("")

    # --- Cross-cutting hubs (from graph analysis) ---
    if graph:
        hubs = _find_hub_discoveries(graph)
        if hubs:
            for hub_path, importer_count, dir_count, blast_radius in hubs[:3]:
                lines.append("  Cross-cutting hub:")
                lines.append(
                    f"    {hub_path} is imported by "
                    f"{importer_count} files across {dir_count} modules"
                )
                if blast_radius > importer_count:
                    lines.append(
                        f"    A change here affects "
                        f"{blast_radius} files transitively"
                    )
            lines.append("")

    # --- Volatility surprises ---
    if history and history.file_histories:
        surprises = _find_volatility_surprises(history)
        if surprises:
            lines.append("  Volatility surprise:")
            for path, fh in surprises[:3]:
                lines.append(
                    f"    {path} {g['dash']} {fh.commit_count} commits, "
                    f"{fh.total_lines_changed} lines changed"
                )
            # Annotate if top file has no scope covering it
            if surprises:
                top_path = surprises[0][0]
                has_scope = any(
                    top_path.startswith(s.directory + "/")
                    for s in plan.scopes
                )
                if not has_scope:
                    lines.append(
                        "    Most changed file in the repo. "
                        "No .scope context exists for it."
                    )
            lines.append("")

    return lines


def _extract_validation(plan: IngestPlan, g: Optional[dict] = None) -> List[str]:
    """Extract validation stats: backtest recall + token reduction."""
    if g is None:
        g = _glyphs()
    lines: List[str] = []
    report = plan.backtest_report

    if not report or report.total_commits == 0:
        return lines

    lines.append(
        f"  Backtested against {report.total_commits} recent commits:"
    )
    lines.append(
        f"  Overall recall: {report.overall_recall:.0%} {g['dash']} "
        f"scopes would have given agents the right files"
    )

    # Token reduction ratio — the single most compelling number
    real_scopes = [
        s for s in plan.scopes
        if not s.directory.startswith("virtual/")
    ]
    if plan.total_repo_tokens > 0 and real_scopes:
        avg_scope_tokens = sum(
            s.config.tokens_estimate or 0 for s in real_scopes
        ) / max(len(real_scopes), 1)
        reduction = (1 - avg_scope_tokens / plan.total_repo_tokens) * 100
        lines.append(
            f"  Token reduction: {reduction:.0f}% {g['dash']} "
            f"from ~{plan.total_repo_tokens:,} to "
            f"~{int(avg_scope_tokens):,} average per resolution"
        )

    lines.append("")

    # Per-scope recall bars
    for result in report.results:
        scope_name = os.path.basename(os.path.dirname(result.scope_path))
        if result.total_commits == 0:
            continue
        filled = int(result.recall * 10)
        bar = g["bar_full"] * filled + g["bar_empty"] * (10 - filled)
        suffix = f" {g['attention']}" if result.recall < 0.8 else ""
        lines.append(
            f"  {scope_name:<12} {bar} {result.recall:.0%} recall{suffix}"
        )

    return lines


def _cache_invariants(root: str, history: Optional[HistoryAnalysis]) -> None:
    """Cache invariants.json with contracts, function_co_changes, and file_stabilities."""
    if not history:
        return

    dot_dir = os.path.join(root, ".dotscope")
    os.makedirs(dot_dir, exist_ok=True)

    contracts = []
    for ic in history.implicit_contracts:
        contracts.append({
            "trigger_file": ic.trigger_file,
            "coupled_file": ic.coupled_file,
            "confidence": ic.confidence,
            "description": ic.description,
        })

    stabilities = {}
    for path, fh in history.file_histories.items():
        stabilities[path] = {
            "classification": fh.stability,
            "commit_count": fh.commit_count,
        }

    invariants = {
        "contracts": contracts,
        "function_co_changes": {},  # Populated when function-level data available
        "file_stabilities": stabilities,
    }

    import json
    path = os.path.join(dot_dir, "invariants.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(invariants, f, indent=2)
